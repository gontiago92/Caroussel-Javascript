class Caroussel {
    constructor (element, options = {}) {
        this.element = element
        this.options = Object.assign({}, {
            slidesToScroll: 1,
            slidesVisible: 1
        }, options)
        //debugger
        this.container = element.children[0]
        this.slides = [].slice.call(this.container.children)
        this.currentSlide = 0
        let ratio  = this.slides.length / this.options.slidesVisible
        this.container.style.width = (ratio * 100) + '%'
        
        this.slides.forEach(slide => {
            slide.style.width = ((100 / this.options.slidesVisible) / ratio) + "%"
        })
        this.createNavigation()
    }

    createNavigation() {
        let nextButton = this.createDivWithClass('caroussel__next')
        let prevButton = this.createDivWithClass('caroussel__prev')
        this.element.appendChild(nextButton)
        this.element.appendChild(prevButton)
        nextButton.addEventListener('click', this.next.bind(this))
        prevButton.addEventListener('click', this.prev.bind(this))
    }

    next() {
        this.goToItem(this.currentSlide + this.options.slidesToScroll)
    }

    prev() {
        this.goToItem(this.currentSlide - this.options.slidesToScroll)
    }

    /**
     * Déplace le caroussel ver l'élément ciblé
     * @param {number} index 
     */
    goToItem (index) {
        console.log(this.slides)
        if(index < 0) { 
            index = this.slides.length - this.options.slidesToScroll
        } else if(index >= this.slides.length || this.slides[this.currentSlide + this.options.slidesVisible] === undefined) {
            index = 0
        }

        let translateX = index * -100 / this.slides.length
        this.container.style.transform = 'translate3d(' + translateX + '%, 0, 0)'
        this.currentSlide = index

    }

    createDivWithClass(className) {
        let div = document.createElement('div')
        div.setAttribute('class', className)
        return div
    }

}